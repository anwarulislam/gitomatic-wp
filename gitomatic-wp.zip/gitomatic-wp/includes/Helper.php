<?php
namespace GitomaticWP;

/**
 * Helper class
 */
class Helper {

	/**
	 * Get the plugin name
	 *
	 * @return string
	 */
	public static function menu_slug() {
		return 'gitomatic-wp';
	}

	/**
	 * Get the theme install page url
	 *
	 * @return string
	 */
	public static function install_theme_url() {
		$menu_slug             = self::menu_slug();
		$path                  = "admin.php?page={$menu_slug}-install-theme";
		$theme_istall_page_url = is_multisite() ? network_admin_url( $path ) : admin_url( $path );

		return $theme_istall_page_url;
	}

	/**
	 * Get the plugin install page url
	 *
	 * @return string
	 */
	public static function install_plugin_url() {
		$menu_slug              = self::menu_slug();
		$path                   = "admin.php?page={$menu_slug}-install-plugin";
		$plugin_istall_page_url = is_multisite() ? network_admin_url( $path ) : admin_url( $path );

		return $plugin_istall_page_url;
	}

	/**
	 * Get the dashboard url
	 *
	 * @return string
	 */
	public static function dashboard_url() {
		$menu_slug     = self::menu_slug();
		$path          = "admin.php?page={$menu_slug}";
		$dashboard_url = is_multisite() ? network_admin_url( $path ) : admin_url( $path );

		return $dashboard_url;
	}

	/**
	 * Get the available providers
	 *
	 * @return array
	 */
	public static function available_providers() {
		return array(
			'bitbucket' => 'Bitbucket',
			'github'    => 'GitHub',
			'gitea'     => 'Gitea',
			'gitlab'    => 'GitLab',
		);
	}

	/**
	 * Get the provider class
	 *
	 * @param  string $provider Provider name.
	 * @return string
	 */
	public static function get_provider_class( $provider ) {
		// phpcs:disable Squiz.PHP.NonExecutableCode.Unreachable
		switch ( $provider ) {
			case 'bitbucket':
				return '\GitomaticWP\Providers\BitbucketProvider';
			break;
			case 'github':
				return '\GitomaticWP\Providers\GithubProvider';
			break;
			case 'gitea':
				return '\GitomaticWP\Providers\GiteaProvider';
			break;
			case 'gitlab':
				return '\GitomaticWP\Providers\GitlabProvider';
			break;

			default:
				return '\GitomaticWP\Providers\BitbucketProvider';
			break;
		}
		// phpcs:enable Squiz.PHP.NonExecutableCode.Unreachable
	}

	/**
	 * Generate the api secret
	 *
	 * @return string
	 */
	public static function generate_api_secret() {
		$key = bin2hex( random_bytes( 32 ) );
		return update_option( 'gitomatic_wp_api_secret', $key );
	}

	/**
	 * Get the api secret
	 *
	 * @return string|boolean false
	 */
	public static function get_api_secret() {
		return get_option( 'gitomatic_wp_api_secret', false );
	}

	/**
	 * Check if WpRocket plugin is activated.
	 *
	 * @return boolean
	 */
	public static function wp_rocket_activated() {
		return function_exists( 'rocket_clean_domain' );
	}

	/**
	 * Check if WP Optimize plugin is activated.
	 *
	 * @return boolean
	 */
	public static function wp_optimize_activated() {
		return class_exists( 'WP_Optimize' );
	}

	/**
	 * Check if W3 Total Cache plugin is activated.
	 *
	 * @return boolean
	 */
	public static function w3tc_activated() {
		return function_exists( 'w3tc_pgcache_flush' );
	}

	/**
	 * Check if LiteSpeed Cache plugin is activated.
	 *
	 * @return boolean
	 */
	public static function litespeed_cache_activated() {
		return has_action( 'litespeed_purge_all' );
	}

	/**
	 * Check if WP Super Cache plugin is activated.
	 *
	 * @return boolean
	 */
	public static function wp_super_cache_activated() {
		return function_exists( 'wp_cache_clear_cache' );
	}

	/**
	 * Check if WP Fastest Cache plugin is activated.
	 *
	 * @return boolean
	 */
	public static function wp_fastest_cache_activated() {
		return ( isset( $GLOBALS['wp_fastest_cache'] ) && method_exists( $GLOBALS['wp_fastest_cache'], 'deleteCache' ) );
	}

	/**
	 * Check if Autoptimize plugin is activated.
	 *
	 * @return boolean
	 */
	public static function autoptimize_activated() {
		return method_exists( 'autoptimizeCache', 'clearall' );
	}

	/**
	 * Check if Breeze plugin is activated.
	 *
	 * @return boolean
	 */
	public static function breeze_activated() {
		return class_exists( 'Breeze_PurgeCache' );
	}

	/**
	 * Trigger cache flush
	 *
	 * @return void
	 */
	public static function trigger_cache_flush() {
		if ( self::wp_rocket_activated() ) {
			\rocket_clean_domain();
		}

		if ( self::wp_optimize_activated() ) {
			if ( method_exists( 'WP_Optimize', 'get_page_cache' ) && method_exists( \WP_Optimize()->get_page_cache(), 'purge' ) ) {
				\WP_Optimize()->get_page_cache()->purge();
			}
		}

		if ( self::w3tc_activated() ) {
			\w3tc_pgcache_flush();
		}

		if ( self::litespeed_cache_activated() ) {
			do_action( 'litespeed_purge_all' );
		}

		if ( self::wp_super_cache_activated() ) {
			\wp_cache_clear_cache();
		}

		if ( self::wp_fastest_cache_activated() ) {
			$GLOBALS['wp_fastest_cache']->deleteCache( true );
		}

		if ( self::autoptimize_activated() ) {
			\autoptimizeCache::clearall();
		}

		if ( self::breeze_activated() ) {
			do_action( 'breeze_clear_all_cache' );
		}
	}

	/**
	 * Get the edit package page url
	 *
	 * @param string $slug Package slug.
	 * @param string $type Package type (plugin or theme).
	 * @return string
	 */
	public static function edit_package_url( $slug, $type ) {
		$menu_slug = self::menu_slug();
		$base_url  = is_multisite() ? network_admin_url( 'admin.php' ) : admin_url( 'admin.php' );
		return add_query_arg(
			array(
				'page'         => "{$menu_slug}-edit-package",
				'package_slug' => $slug,
				'package_type' => $type,
			),
			$base_url
		);
	}

	/**
	 * Check if GitHub token is a fine-grained personal access token
	 *
	 * @param string $token GitHub token.
	 * @return boolean
	 */
	public static function is_github_pat_token( $token ) {
		if ( empty( $token ) ) {
			return false;
		}
		return strpos( $token, 'github_pat_' ) !== false;
	}

	/**
	 * Format a WP_Error or string into a descriptive, user-friendly error message.
	 *
	 * @param mixed $error Error object or message.
	 * @return string Formatted error message.
	 */
	public static function format_error_message( $error ) {
		if ( ! is_wp_error( $error ) ) {
			return is_string( $error ) ? $error : __( 'An error occurred.', 'gitomatic-wp' );
		}

		$messages     = $error->get_error_messages();
		$main_message = ! empty( $messages ) ? implode( ' ', $messages ) : __( 'An error occurred.', 'gitomatic-wp' );
		$data         = $error->get_error_data();

		$reason = '';
		if ( ! empty( $data ) ) {
			if ( is_string( $data ) ) {
				$reason = $data;
			} elseif ( is_array( $data ) ) {
				if ( ! empty( $data['reason'] ) ) {
					$reason = $data['reason'];
				} elseif ( ! empty( $data['api_message'] ) ) {
					$reason = $data['api_message'];
				} elseif ( ! empty( $data['error_message'] ) ) {
					$reason = $data['error_message'];
				} elseif ( ! empty( $data['raw_error'] ) && is_string( $data['raw_error'] ) ) {
					$reason = $data['raw_error'];
				}
			}
		}

		if ( '' !== $reason && false === strpos( $main_message, $reason ) ) {
			$main_message = rtrim( $main_message, '.' ) . ': ' . $reason;
		}

		return $main_message;
	}
}
